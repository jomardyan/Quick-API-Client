const DEFAULT_TIMEOUT_MS = 15000;
const DEBUG_LOGGING = false;

// Track in-flight requests so cancellation can abort them
const pendingRequests = new Map(); // requestId -> AbortController

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  // Handle cancellation from popup
  if (message?.type === "cancel-request") {
    const controller = pendingRequests.get(message.payload?.requestId);
    if (controller) {
      controller.abort();
      pendingRequests.delete(message.payload.requestId);
    }
    return; // no async response needed
  }

  if (message?.type !== "api-request") return;

  const { url, method, headers, body, timeoutMs, requestId } = message.payload;
  const effectiveTimeout =
    typeof timeoutMs === "number" && timeoutMs > 0 ? timeoutMs : DEFAULT_TIMEOUT_MS;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), effectiveTimeout);

  if (requestId) pendingRequests.set(requestId, controller);

  const started = performance.now();

  (async () => {
    try {
      // Validate URL
      try {
        new URL(url);
      } catch (err) {
        sendResponse({
          ok: false,
          error: "Invalid URL format",
        });
        return;
      }

      const fetchOptions = {
        method,
        headers,
        signal: controller.signal,
        mode: 'cors',
        credentials: 'omit'
      };

      if (body && !['GET', 'HEAD'].includes(method)) {
        fetchOptions.body = body;
      }

      if (DEBUG_LOGGING) console.log("Fetching", url, fetchOptions);
      const res = await fetch(url, fetchOptions);
      const text = await res.text();
      const elapsed = Math.round(performance.now() - started);
      const headersEntries = Array.from(res.headers.entries());

      if (DEBUG_LOGGING) console.log("Fetch success", res.status);
      sendResponse({
        ok: true,
        status: res.status,
        statusText: res.statusText,
        url: res.url,
        type: res.type,
        elapsed,
        headers: headersEntries,
        body: text,
      });
    } catch (err) {
      console.error('API request error:', err);
      const elapsed = Math.round(performance.now() - started);
      sendResponse({
        ok: false,
        error:
          err.name === "AbortError"
            ? `Request timed out after ${Math.round(effectiveTimeout / 1000)}s`
            : err.name === "TypeError" && err.message.includes("fetch")
            ? "Network error: Unable to reach the server. Check your connection or the URL."
            : err.message || "Unknown error occurred",
        elapsed,
      });
    } finally {
      clearTimeout(timeout);
      if (requestId) pendingRequests.delete(requestId);
    }
  })();

  return true; // keep the message channel open for async response
});

// Log extension startup
if (DEBUG_LOGGING) {
  console.log("Quick API Client: Background service worker started");
}
